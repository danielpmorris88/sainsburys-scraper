Sainsbury's Scraper

What is it?
-----------

This Sainsbury's Scraper is a console application that extracts data from 
Sainsbury's grocery site. This Scraper applicaton is desgined to output 
this grocery data in JSON format. The data provided will contain:
 Title
 Unit Price 
 Description
 Size

How to use
----------

Open command line

1. Get Product List in Json format run:
 <path to directory>/get_product_information.php
 
2. To run test scrips
	<path to directory>/tests/run_test_scripts.php
	

Installation
------------

Dependencies:
 PHP 5 and above
 
Extract Scraper.zip to path


Author
------

Daniel Morris

