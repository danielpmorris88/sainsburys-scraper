<?php 

/** 
 * Class WebDocument - Webdocumnet object containing Web page data
 */
class WebDocument {
	/** 
	 * @var string html - String of html page
	 */
	public $html;
	public $url;
	
	/**
 	* Constructor function to get url property
 	* @param string url - url of webpage
 	*/
	public function __construct($url){
		$this->url = $url;
	}
	
	/**
 	* Get Webpage contents and assign contents to html property
 	*/
	public function getWebDocumentContent(){
		$this->html = file_get_contents($this->url);
	}
}

/** 
 * Class WebDocument - DomDocument object containg webpage data
 * @extents WebDocument 
 */
class WebDomDocument extends WebDocument {
	/** 
	 * @var object domdocument - DomDocument object 
	 */
	public $domdocument;
	
	/**
 	* Constructor function calling its parent constructor then creating a DomDocument object
 	* @param string url - url of webpage
 	*/
	public function __construct($url){
		parent::__construct($url);
		$this->getWebDocumentContent();
		$this->domdocument = new DOMDocument();
	}
	
	/**
 	* Load html property into DomDocument Object
 	*/
	protected function loadDomHtml(){
		$this->domdocument->loadHTML($this->html);
		libxml_clear_errors();
	}
}

/** 
 * Class WebDomxPath - DOMXPath object within the DomDocument object
 * @extents WebDomDocument
 */
class WebDomxPath extends WebDomDocument {
	/** 
	 * @var object domx_document - DOMXPath object 
	 * @var array sections - Array of product sections (html) from which to extract links to 
	 * individual product pages
	 * @var object section - subset of DomDocument object for product section
	 * @var object productlist - instance of ProductList object 
	 */
	public $domx_document;
	public $sections = array(); 
	public $section;
	public $productlist;
		
	/**
 	* Constructor function calling its parent constructor and then creating an DOMXPath for 
 	* querying individual product sections
 	* @param string url - url of webpage
 	*/
	public function __construct($url){
		parent::__construct($url);
		$this->loadDomHtml();
		$this->domx_document = new DOMXPath($this->domdocument);
	}
	
	/**
 	* Query DOMXPath to get section of webpage ad store it in the section property
 	* @param classname - class name to search html document for
 	*/
	public function getDomxSection($classname){
		$this->section = $this->domx_document->query('//*[@class="'.$classname.'"]');
	}
	
	/**
 	* Query DOMXPath to get multiple sections of webpage ad store them as an array within the 
 	* sections property
 	* @param string classname - class name to search html document for
 	*/
	public function getDomxSections($classname){
		$this->getDomxSection($classname);
		if($this->section->length > 1){
			foreach($this->section as $section){
				$this->sections[] = $this->domdocument->saveXML($section);
			}
		}
	}
	
	/**
 	* Create ProuctList Object
 	*/
	public function createProductList(){
		$this->productlist = new ProductList($this->sections);
	}
	
	/**
 	* Create ProuctList Object and get the productlist in array format
 	*/
	public function getWebDocProductList(){
		$this->createProductList();
		return $this->productlist->getProductList();
	}
	
	/**
 	* Create ProductList Object and get the productlist in json format
 	*/
	public function getWebDocProductListJson(){
		$this->createProductList();
		return $this->productlist->getProductListJson();
	}
}