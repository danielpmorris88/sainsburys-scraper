<?php

/** 
 * Class Product - product object with name, description, unit price and Xpath
 */
class Product {	
	/** 
	 * @var object productxpath - Product url, html, domdocument
	 * @var string name - name of product
	 * @var mixed unitprice - unit price of product
	 * @var string description - description of product
	 */
	public $productxpath;
	public $name;
	public $unitprice;
	public $description;
	
	/**
 	* Constructor function assigning productxpath, name unitprice and description properties
 	* @param array sections - array of html sections
 	*/
	public function __construct($productxpath){
		$this->productxpath = $productxpath;
		$this->name = $this->getName();
		$this->unitprice = $this->getUnitPrice();
		$this->description = $this->getDescription();
	}
	
	/**
 	* extracts the html element from the section and returns its nodeValue
 	* @param string classname - html element class name
 	*/
	public function getElement($classname){
		$this->productxpath->getDomxSection($classname);
		foreach($this->productxpath->section as $element){
			return $element->nodeValue;
		}
	}
	
	/**
 	* returns name of product
 	*/
	public function getName(){
		return trim($this->getElement("productTitleDescriptionContainer"));
	}
	
	/**
 	* returns unit price of product
 	*/
	public function getUnitPrice(){
		preg_match("/(\d+(\.\d+)?)/",trim($this->getElement("pricePerUnit")),$price_matches);
		return $price_matches[1];
	}
	
	/**
 	* returns description of product
 	*/
	public function getDescription(){
		return trim($this->getElement("productText"));
	}
}