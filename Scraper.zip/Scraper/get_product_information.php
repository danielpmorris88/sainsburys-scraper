#!/usr/bin/php
<?php

include("global.php");

$scraper_xml = new WebDomxPath(URL);
$scraper_xml->getDomxSections('productInfo');
echo $scraper_xml->getWebDocProductListJson();
