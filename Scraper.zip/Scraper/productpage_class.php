<?php

/** 
 * Class ProductPage - Individual product webpage containg xml data, product 
 * data and web page property data
 */
class ProductPage {
	/** 
	 * @var string link - link to individual product page
	 * @var object pagexpath - Document XPATH for querying pattern
	 * @var object product - Product object
	 * @var string size - size of individual product page
	 */
	public $link;
	public $pagexpath;
	public $product;
	public $size;
	
	/**
 	* Constructor function assigning link property, creating a ProductPage object ad creating a
 	* Product object
 	* @param string url - individual product page link
 	*/
	public function __construct($link){
		$this->link = $link;
		$this->createProductPage();
		$this->createProduct();
	}
	
	/**
 	* Create a WebDomXpath object now for the individual product pages
 	*/
	public function createProductPage(){
		$this->pagexpath = new WebDomxPath($this->link);
	}
	
	/**
 	* Create a product object for page
 	*/
	public function createProduct(){
		$this->product = new Product($this->pagexpath);
	}
	
	/**
	* Calculate the size of the product page in kb and assign value to size property
 	*/
	public function getPageSize(){
		$headers = get_headers($this->link);
		foreach($headers as $header_attribute){
			if(false !== strpos($header_attribute, 'Content-Length')){
				$this->size = ((int)str_replace("Content-Length: ","",$header_attribute)/1000)."kb";
			}
		}
	}
}