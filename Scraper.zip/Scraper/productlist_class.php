<?php

/** 
 * Class ProductList - list of products, their raw data and their attributes
 */
class ProductList {
	/** 
	 * @var array sections - array of sections from WebDomxPath
	 * @var array jsonresult - array of products and their attributes
	 * @var array productlinks - array of all product links
	 * @var array productpages - array of all product pages (each in html format)
	 */
	public $sections;
	public $jsonresult = array(
		'results' => array()
	);
	public $productlinks = array();
	public $productpages = array();
	
	/**
 	* Constructor function assigning section property to what was received from WebDomxPath
 	* @param array sections - array of html sections
 	*/
	public function __construct($sections){
		$this->sections = $sections;
	}
	
	/**
 	* gets Product list in array of html strings
 	*/
	public function getProductList(){
		$this->getProductLinks();
		return $this->getProductPages();
	}
	
	/**
 	* gets json encode product list with product title, description, unit_price, page size and
 	* a total price
 	*/
	public function getProductListJson(){
		$this->getProductList();
		$i = 0;
		$product_price = 0;
		foreach ($this->productpages as $product_data){
			$product_data->getPageSize();
			$product_array[$i]['title'] = $product_data->product->name;
			$product_array[$i]['unit_price'] = $product_data->product->unitprice;
			$product_array[$i]['description'] = $product_data->product->description;
			$product_array[$i]['size'] = $product_data->size;
			$product_price = $product_price + $product_array[$i]['unit_price'];
			$i++;
		}
		$this->jsonresult['results'] = $product_array;
		$this->jsonresult['results']['total'] = number_format($product_price,2);
		return json_encode($this->jsonresult);
	}
	
	/**
 	* gets links to all product pages
 	*/
	public function getProductLinks(){
		$i=0;
		foreach($this->sections as $section_xml){
			$xml_object = simpleXML_load_string($section_xml);
			foreach($xml_object->h3->a->attributes() as $link_attributes){
				$this->productlinks[$i] = trim($link_attributes[0]);
			}
			$i++;
		}
	}
	
	/**
 	* gets array of product page html
 	*/
	public function getProductPages(){
		foreach($this->productlinks as $link){
			$this->productpages[] = $this->createProductPage($link);
		}
	}
	
	/**
 	* creates a Product Page from a link
 	* @param string link - link to individual webpage
 	*/
	public function createProductPage($link){
		return new ProductPage($link);
	}
}