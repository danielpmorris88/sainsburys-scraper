<?php

//Defines
define('URL','http://hiring-tests.s3-website-eu-west-1.amazonaws.com/2015_Developer_Scrape/5_products.html');

libxml_use_internal_errors(TRUE);

//Includes
include("webdocument_class.php");
include("productlist_class.php");
include("productpage_class.php");
include("product_class.php");
