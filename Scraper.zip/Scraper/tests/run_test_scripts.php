#!/usr/bin/php
<?php 
$apppath = str_replace(basename($_SERVER['SCRIPT_FILENAME']),"",__FILE__);
$apppath = str_replace("tests","",$apppath);
$apppath = substr_replace($apppath ,"",-1);
chdir($apppath);

include("global.php");
include("tests/assert_class.php");
include("tests/executetests_class.php");
include("tests/scrapertest_class.php");

$test = new ScraperTest();

$test_results = $test->runTests();
$test->print_output();