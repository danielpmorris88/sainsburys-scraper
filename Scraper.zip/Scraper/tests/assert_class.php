<?php

/**
 * Provides Assertions
 **/
class Assert {
   
   public static function areEqual( $a, $b ){
    	if ( $a != $b ){
    		throw new Exception( 'Subjects are not equal.' );
    	}
    }
    
    public static function isNull($value){
    	if(null == $value){
    		throw new Exception( 'Value is null.' );
    	}
    }
    
    public static function greaterThanZero($value){
    	if($value <= 0){
    		throw new Exception( 'Value is zero.' );
    	}
    }
    
    public static function arrayNotEmpty($value){
    	if(count($value) == 0){
    		throw new Exception( 'Array is empty.' );
    	}
    }
}