<?php

class ScraperTest extends executeTests{
     
     /**
     * This test is designed to show a failure
     **/
    public function testUrlFail(){
    	Assert::isNull(null);
    }
    
    /**
     * This test is designed to check the URL is not null
     **/
    public function testUrl(){
    	Assert::isNull(URL);
    }
    
    /**
     * This test is designed to check file get contents of the URL 
     * is not null
     **/
    public function TestHtml(){
    	$doc = new WebDocument(URL);
    	$doc->getWebDocumentContent();
    	Assert::isNull($doc->html);
    }

    /**
     * This test is designed to check the URL html has been loaded 
     * into the WebDomDocument object
     **/
   public function testWebDomDocument(){
    	$domdoc = new WebDomDocument(URL);
    	Assert::isNull($domdoc->html);
    }
    
    /**
     * This test is designed to check WebDomXPath objects html 
     * has a class of productInfo inside to get the links for the 
     * individual product pages.
     **/
    public function testWebDomxPathSectionExists(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSection('productInfo');
    	Assert::greaterThanZero($domdocx->section->length);
    }
    
    /**
     * This test is designed to check that there are multiple  
     * products displayed on the page.
     **/
    public function multipleProductsExist(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	Assert::greaterThanZero($domdocx->section->length);
    }
    
     /**
     * This test is designed to check that the links can be 
     * extracted from the page.
     **/
    public function testProductLinks(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	$domdocx->createProductList($domdocx->sections);
    	$domdocx->productlist->getProductLinks();
    	Assert::arrayNotEmpty($domdocx->productlist->productlinks);
    }
    
    /**
     * This test is designed to check that the individual product pages
     * can be acessed
     **/
    public function testProductPages(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	$domdocx->createProductList($domdocx->sections);
    	$domdocx->productlist->getProductlinks();
    	$domdocx->productlist->getProductpages();
    	Assert::arrayNotEmpty($domdocx->productlist->productpages);
    }
    
    /**
     * This test is designed to check that the individual product pages
     * have a page size
     **/
    public function testProductPageSize(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	$domdocx->createProductList($domdocx->sections);
    	$domdocx->productlist->getProductlinks();
    	foreach($domdocx->productlist->productlinks as $page){
    		$productpage = new ProductPage($page);
    		$productpage->getPageSize();
    		Assert::greaterThanZero($productpage->size);
    		break 1;
    	}
    }
    
    /**
     * This test is designed to check that the individual product pages
     * contain a product name
     **/
    public function testProductName(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	$domdocx->createProductList($domdocx->sections);
    	$domdocx->productlist->getProductList();
    	foreach($domdocx->productlist->productlinks as $page){
    		$domdocx->productlist->createProductPage($page);
    		Assert::isNull($domdocx->productlist->productpages[0]->product->name);
    		break 1;
    	}
    }
    
    /**
     * This test is designed to check that the individual product pages
     * contain a product unit price
     **/
    public function testProductUnitPrice(){
    	$domdocx = new WebDomxPath(URL);
    	$domdocx->getDomxSections('productInfo');
    	$domdocx->createProductList($domdocx->sections);
    	$domdocx->productlist->getProductList();
    	foreach($domdocx->productlist->productlinks as $page){
    		$domdocx->productlist->createProductPage($page);
    		Assert::isNull($domdocx->productlist->productpages[0]->product->unitprice);
    		break 1;
    	}
    }
}