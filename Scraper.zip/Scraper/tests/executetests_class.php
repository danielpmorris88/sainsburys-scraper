<?php

class ExecuteTests {
	
	public $result = array();
	
	public function buildTestResult($i,$success,$test,$filename = '' ,$message = ''){
		$this->result[$i]->success = $success;
		$this->result[$i]->test = $test;
		$this->result[$i]->filename =$filename;
		$this->result[$i]->message = $message;
	}
	
	public function print_output(){
		print_r($this->result);
	}

 	public function runTests(){
		$excludeFunctionNames = array('runTests','buildTestResult','print_output');
		$class = new ReflectionClass( $this );
		$i=0;
   		foreach( $class->GetMethods() as $method ){
   			$methodname = $method->getName();
   			if(false == in_array($methodname,$excludeFunctionNames)){
   				try{
   					$this->$methodname();
   					$this->buildTestResult($i,'true',$methodname);
   				}
   				catch ( Exception $ex ){
   					 $this->buildTestResult($i,'false',$methodname,$ex->getFile(),$ex->getMessage());
   				}
   				$i++;
   			}
  		}
  	}
}